type command = {w: bool;
                a: bool;
                s: bool;
                d: bool;
                j: bool;
                k: bool;
                l: bool}

(* let keystates = get_key_state () in
   if keystates.{ int_of_key KEY_UP } <> 0 then *)
               
(* Up key was pressed *) 
